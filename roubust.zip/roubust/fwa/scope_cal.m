function scope_array = scope_cal(fitness_array, params)
% 这个函数用来计算火花的范围 对应论文的(4)式
global Coef_Explosion_Amplitude;% 爆炸范围系数

% 找出最佳（最低）适应度值
fitness_best = min(fitness_array);
% 用最佳适应度值去逐个减适应度值向量 并取绝对值
fitness_sub_best = abs(fitness_best - fitness_array);
% 求和
fitness_sub_best_sum = sum(fitness_sub_best);
% 范围矩阵 seednum*seednum大小
scope_array = zeros(params.seednum);

% 对每一个种子（烟花） 计算其爆炸范围
for i=1:params.seednum
    scope_array(i) = Coef_Explosion_Amplitude * (fitness_sub_best(i) + eps) / (fitness_sub_best_sum + eps);  
end
