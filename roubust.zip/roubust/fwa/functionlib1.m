function y=functionlib1(x)
y=benchmark14(x,1);
