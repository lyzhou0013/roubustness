clc;clear;
run('.\MAIN0107.m');
clc;clear;
run('.\MAIN0810.m');
clc;clear;
run('.\MAIN1112.m');