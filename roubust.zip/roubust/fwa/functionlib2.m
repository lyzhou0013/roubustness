function y=functionlib2(x)

y=benchmark14(x,2);
