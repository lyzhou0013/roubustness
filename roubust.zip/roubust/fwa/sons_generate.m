function [sons_matrix, sons_fitness_array, fitness_best_array] = sons_generate(sonsnum_array, scope_array, seeds_matrix, params,fitness_best_array)
%% 传入参数说明
% sonsnum_array 由sonnum_cal.m文件函数生成 是1行seednum列的行向量 装的是每一个烟花将要生成的火花数目
% scope_array 由scope_cal.m文件生成 是seednum*seednum矩阵 第一列为每个烟花生成火花的范围 其余为0
% seeds_matrix 烟花的位置矩阵 
% params 内含各种参数的数据结构
% fitness_best_array 存每个烟花的最佳适应度的向量
%% 该文件该函数对应论文Algorithm 1 
global total_fiteval_times;
global evaTime;

fiteval_time = sum(sonsnum_array);% 每个烟花将要爆发的火花的总数
total_fiteval_times = total_fiteval_times + fiteval_time;% 可能还加上原火花数吧

% 火花位置矩阵 fiteval_time*params.dim 全0
sons_matrix = zeros(fiteval_time, params.dim);
% 火花适应度值向量 1*fiteval_time 全0
sons_fitness_array = zeros(1, fiteval_time);    


sons_index = 1; 

% 对每个种子（烟花）遍历
for i = 1 : params.seednum
    % 对每个烟花将要爆发的火花数遍历 生成火花过程
    for j = 1 : sonsnum_array(i)
	% 取出种子位置
        seed_position = seeds_matrix(i,:);
         % 全1向量 1*params.dim 表示允许的维度的列表
        allowed_dim_array = ones(1,params.dim);
         % 随机数*维度再取整 选择维度数 对应论文(5)式 求出随机选择将要变异的维度数目
        dimens_select = ceil(rand*params.dim); %select dimens_select
		% [-1,1]随机数*爆炸范围 = 偏移量
        offset = (rand*2-1) * scope_array(i); %Calculate the displacement:
        % 执行前面求得的将要变异的维度数目次
        for k = 1 : dimens_select
            % 随机选择火花维度
            rand_dimen = ceil(rand*params.dim);
			 % 若该维度已经变异过 则重新选择维度
            while allowed_dim_array(rand_dimen)==0  
                rand_dimen = ceil(rand*params.dim);
            end
            % 对标记向量置0
            allowed_dim_array(rand_dimen)=0;
			% 火花根据烟花的位置做偏移 在前面随机选到的rand_dims维度上
            seed_position(rand_dimen) = seed_position(rand_dimen) + offset;
            % 对新生成的火花做界限规范
            if seed_position(rand_dimen) > params.upperBound || seed_position(rand_dimen) < params.lowerBound
			% map to the search range of the sparks which are out of the bound
             % 当超出界限时重新映射到范围之内
                span = params.upperBound - params.lowerBound;
                seed_position(rand_dimen) = params.lowerBound + rem(abs(seed_position(rand_dimen)), span);
            end
        end

        % 对火花位置矩阵更新
        sons_matrix(sons_index,:) = seed_position;
        % index++
        sons_index = sons_index + 1;
    end
end
% 遍历所有的火花
for i = 1 : fiteval_time
    % 使用指定函数计算适应度值
    sons_fitness_array(i) = feval(params.fun_name, sons_matrix(i,:));
    % 更新全局最佳适应度值
	 if(sons_fitness_array(i)<fitness_best_array(evaTime))
		fitness_best_array(evaTime+1) = sons_fitness_array(i);
	 else
		fitness_best_array(evaTime+1) = fitness_best_array(evaTime);
	 end
	 evaTime = evaTime + 1;
end
