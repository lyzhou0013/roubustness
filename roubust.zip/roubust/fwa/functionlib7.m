function y=functionlib7(x)
% benchmark_func.m is the main function for 25 test functions, all minimize
% problems
 

y=benchmark14(x,7);
