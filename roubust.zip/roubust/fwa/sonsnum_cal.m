function sonsnum_array = sonsnum_cal(fitness_array, params)

global Max_Sparks_Num;
global Min_Sparks_Num;
global Coef_Spark_Num;

fitness_max = max(fitness_array); % 得到最大适应度值
fitness_sub_max = abs(fitness_max - fitness_array);% 适应度值向量减去最大适应度值 再依次取绝对值
fitness_sub_max_sum = sum(fitness_sub_max);% 8行的值求和

sonsnum_array = zeros(1, params.seednum);% 1行seednum列的0向量 
% 遍历seednum次
for i = 1 : params.seednum
  % eps 机器最小值 防止除0运算
    % fitness_sub_max(i) 就是北大谭营教授和朱元春同学的论文中的(2)式的y_max-f(x_i)
    % fitness_sub_max_sum 就是(2)式中的sigma(y_max - f(x_i))
    sonnum_temp = (fitness_sub_max(i) + eps) / (fitness_sub_max_sum + eps);
    sonnum_temp = round( sonnum_temp * Coef_Spark_Num);

     % 对火花数做限制
     
     
    if sonnum_temp > Max_Sparks_Num
        sonnum_temp = Max_Sparks_Num;
    elseif sonnum_temp < Min_Sparks_Num
            sonnum_temp = Min_Sparks_Num;
    end
	
    sonsnum_array(i) = sonnum_temp; 
end


