 [FrontValue,MaxFront] = NonDominateSort(FunctionValue,1);
% xmax=max(FunctionValue(:,1));
% xmin=min(FunctionValue(:,1));
% ymax=max(FunctionValue(:,2));
% ymin=min(FunctionValue(:,2));
% FV=(FunctionValue-[xmin,ymin])./([xmax,ymax]-[xmin,ymin]);
% norm=sqrt(FV(:,1).^2+FV(:,2).^2);
[~,opt_pos]=min(FunctionValue(:,1));
[zk,kz]=find(FunctionValue(:,1)>0.1);
FrontValue(zk)=4;
opt_val=[FunctionValue(opt_pos,1),FunctionValue(opt_pos,2)];
opt_sol=[Population(opt_pos,1),Population(opt_pos,2)];
optimal=[opt_pos opt_sol opt_val];
FrontCurrent = find(FrontValue==1);
n1=length(FrontCurrent);
close all
figure(1)
hold on
h1=plot(FunctionValue(FrontCurrent,1),FunctionValue(FrontCurrent,2),'*');
h2=plot(FunctionValue(opt_pos,1),FunctionValue(opt_pos,2),'.','Color','r','MarkerSize',20);
legend([h1,h2],{'first frontier','optimal'})
xlabel('-|r_1-r_2|')
ylabel('-(r_1+r_2)')
grid on
box on
figure(2)
hold on
yy3=[y22(177:407)];
xx3=[x22(177:407)];
n=length(yy3);
for i=1:n
    yz(i)=yy3(n+1-i);
    xz(i)=xx3(n+1-i);
end
yx3=[y2(8:236),yz];
xy3=[x2(8:236),xz];
hold on 
r1 = 0.5*FunctionValue(opt_pos,2);%半径
% r2=0.365;
a1 = Population(opt_pos,1);%横坐标
b1 = Population(opt_pos,2);%纵坐标 
theta = 0:pi/30:2*pi; %角度[0,2*pi] 
xz1 = a1+r1*cos(theta);
yz1 = b1+r1*sin(theta);
% xz2 = a1+r2*cos(theta);
% yz2 = b1+r2*sin(theta);
% plot(xz2,yz2,'LineWidth',2,'Color','k')
h1=fill(xy3,yx3,[.0,.0,.0],'FaceAlpha',0.1);
h2=plot(x22,y22,'LineWidth',2,'Color',[0.43 0.71 0.92]);
h3=plot(x2,y2,'LineWidth',2,'Color',[0.95 0.35 0.21]);
h4=plot(x4,y4,'--k');
% DrawGraph(Population(FrontCurrent,:));
h5=plot(Population(opt_pos,1),Population(opt_pos,2),'.','Color','r','MarkerSize',20);
h6=plot(xz1,yz1,'LineWidth',2,'Color','k');
legend([h2,h3,h4],{'G=65','D=0.001','\rho=1'},'Location','northeast')
xlabel('server size m')
ylabel('server speed s')
axis([6 20 0.5 2])
grid on
box on
%  save optimal.mat opt_pos opt_val opt_sol