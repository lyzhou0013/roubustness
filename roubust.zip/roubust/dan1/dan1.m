clear ; clc;
  lb= [0;0]';
     ub = [1;1]';
size=100; % 种群数目
G=10; % Maximum numbef of iterations最大迭代次数
dim=2;
K=50;% 运行次数
MinX(1)=8;%未知量范围
MinX(2)=0.5;
MaxX(1)=20;
MaxX(2)=1.7;
ymat=zeros(K,1);%作用是为了存储最优值而已
r1=0.01;
gd=1;
P=zeros(100,2);
fit=zeros(100,1);
for i=1:1:dim
    cs(:,i)=MinX(i)+(MaxX(i)-MinX(i))*rand(size,1);
end
for i=1:size
    if G_ms(cs(i,1),cs(i,2)) > 65 &&  9.99 / (cs(i,1)*cs(i,2))<1%要分情况讨论，还有就是在边界的时候
        %  if 15.*4.*(1-(exp(-cs(i,2).*cs(i,1)+4).*(exp(1).*4).^cs(i,1))./(sqrt(2.*pi.*cs(i,1)).*(cs(i,2).*cs(i,1)-4).*(cs(i,2).*cs(i,1)).^(cs(i,1)-1)+(exp(1).*4).^cs(i,1)))-cs(i,1).*(3+(0.7.*4.*cs(i,2).^(1.1).*2./cs(i,1)+0.3*4))>28.5
        P(gd,:)=cs(i,:);
        fit(gd)=dgm(P(gd,1),P(gd,2));
    end
        gd=gd+1;
    end


P_percent = 0.2;
P_percent1 = 0.4;
P_percent2= 0.63;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pNum = round((gd-1) *  P_percent );    % The population size of the producers
pNum1=round((gd-1) *  P_percent1);
pNum2=round((gd-1) *  P_percent2);
%
% lb= c';    % Lower limit/bounds/     a vector
% ub= d';    % Upper limit/bounds/     a vector
% %Initialization
% for i = 1 : size
%
%     x( i, : ) = lb + (ub - lb) .* rand( 1, dim );
%      fit( i ) = fobj( x( i, : ),Function_name );
% end
%
pFit = fit;
pX = P;
XX=pX;
[ fMax, bestI ] = max( fit );      % fMin denotes the global optimum fitness value
bestX = P( bestI, : );             % bestX denotes the global optimum position corresponding to fMin

% Start updating the solutions.
for t = 1 : G
    
    [fmin,B]=min(fit);
    worse= P(B,:);
    RR=rand(1);
    gg=1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i = 1 : pNum
        
        if(RR<0.9)
            rr=rand(1);
            a=rand(1,1);
            if (a>0.1)
                a=1;
            else
                a=-1;
            end
            P( i , : ) =  pX(  i , :)+0.3*abs(pX(i , : )-worse)+a*0.1*(XX( i , :)); % Equation (1)
        else
            
            aaa= randperm(180,1);
            if ( aaa==0 ||aaa==90 ||aaa==180 )
                P(  i , : ) = pX(  i , :);
            end
            theta= aaa*pi/180;
            
            P(  i , : ) = pX(  i , :)+tan(theta).*abs(pX(i , : )-XX( i , :));    % Equation (2)
            
        end
        
        %         P(  i , : ) = Bounds( P(i , : ), lb, ub );    %边界的约束
        %         fit( i ) = fobj( P( i, : ),Function_name );
        % gg=1;
        fit2=zeros(100,1);
        % if   15.*4.*(1-(exp(-P(i,2).*P(i,1)+4).*(exp(1).*4).^P(i,1))./(sqrt(2.*pi.*P(i,1)).*(P(i,2).*P(i,1)-4).*(P(i,2).*P(i,1)).^(P(i,1)-1)+(exp(1).*4).^P(i,1)))-P(i,1).*(3+(0.7.*4.*P(i,2).^(1.1).*2./P(i,1)+0.3*4))>28.5
        if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1%要分情况讨论，还有就是在边界的时候       
            z(gg,:)=P(i,:);
            if z(gg,1)<MinX(1)
                z(gg,1)=MinX(1);
            end
            if z(gg,2)<MinX(2)
                z(gg,2)=MinX(2);
            end
            if z(gg,2)>MaxX(2)
                z(gg,2)=MaxX(2);
            end
            fit2(gg)=dgm(z(gg,1),z(gg,2));
            gg=gg+1;
            
        else
            continue
        end
    end
    
    
    [ fMMax, bestII ] = max( fit2 );      % fMin denotes the current optimum fitness value
    bestXX = z( bestII, : );             % bestXX denotes the current optimum position
    
    R=1-t/G;                           %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Xnew1e = bestXX.*(1-R);
    Xnew2e =bestXX.*(1+R);                    %%% Equation (3)
    %    Xnew1= Bounds( Xnew1, lb, ub );
    %    Xnew2 = Bounds( Xnew2, lb, ub );
    
    %    if   15.*4.*(1-(exp(-P(i,2).*P(i,1)+4).*(exp(1).*4).^P(i,1))./(sqrt(2.*pi.*P(i,1)).*(P(i,2).*P(i,1)-4).*(P(i,2).*P(i,1)).^(P(i,1)-1)+(exp(1).*4).^P(i,1)))-P(i,1).*(3+(0.7.*4.*P(i,2).^(1.1).*2./P(i,1)+0.3*4))>28.5
    if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1%要分情况讨论，还有就是在边界的时候
        
        Xnew1= Xnew1e;
        if Xnew1(1)<MinX(1)
            Xnew1(1)=MinX(1);
        end
        if Xnew1(2)<MinX(2)
            Xnew1(2)=MinX(2);
        end
        if Xnew1(2)>MaxX(2)
            Xnew1(2)=MaxX(2);
        end
    else
        continue
    end
    
    %    if   15.*4.*(1-(exp(-P(i,2).*P(i,1)+4).*(exp(1).*4).^P(i,1))./(sqrt(2.*pi.*P(i,1)).*(P(i,2).*P(i,1)-4).*(P(i,2).*P(i,1)).^(P(i,1)-1)+(exp(1).*4).^P(i,1)))-P(i,1).*(3+0.7.*(4.*P(i,2).^(1.1).*2./P(i,1)+0.3*4))>28.5
    if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1%要分情况讨论，还有就是在边界的时候
        
        Xnew2= Xnew2e;
        if Xnew2(1)<MinX(1)
            Xnew2(1)=MinX(1);
        end
        if Xnew2(2)<MinX(2)
            Xnew2(2)=MinX(2);
        end
        if Xnew2(2)>MaxX(2)
            Xnew2(2)=MaxX(2);
        end
    else
        continue
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Xnew11 = bestX.*(1-R);
    Xnew22 =bestX.*(1+R);                     %%% Equation (5)
    Xnew11= Bounds( Xnew11, lb, ub );
    Xnew22 = Bounds( Xnew22, lb, ub );
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i = ( pNum + 1 ) :pNum1                 % Equation (4)
        P1( i, : )=bestXX+((rand(1,dim)).*(pX( i , : )-Xnew1)+(rand(1,dim)).*(pX( i , : )-Xnew2));
        if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1%要分情况讨论，还有就是在边界的时候
            
            P(i, : ) =  P1(i, : ) ;
            if  P(i, 1 ) <MinX(1)
                P(i, 1) =MinX(1);
            end
            if  P(i, 2 ) <MinX(2)
                P(i, 2) =MinX(2);
            end
            if  P(i, 2 ) >MaxX(2)
                P(i, 2) =MaxX(2);
            end
            fit(i)=dgm(P1(i,1),P1(i,2));
        else
            continue
        end  
    end
    
    for i =  (pNum1 + 1 ) :pNum2                 % Equation (6)
        
        
        P2( i, : )=pX( i , : )+((randn(1)).*(pX( i , : )-Xnew11)+((rand(1,dim)).*(pX( i , : )-Xnew22)));
        if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1 %要分情况讨论，还有就是在边界的时候
            
            P(i, : ) =  P2(i, : ) ;
            if  P(i, 1 ) <MinX(1)
                P(i, 1) =MinX(1);
            end
            if  P(i, 2 ) <MinX(2)
                P(i, 2) =MinX(2);
            end
            if  P(i, 2 ) >MaxX(2)
                P(i, 2) =MaxX(2);
            end
            fit(i)=dgm(P2(i,1),P2(i,2));
        else
            continue
        end
        
        
    end
    
    for i = (pNum2 + 1 )  : (gd-1)                % Equation (7)
        P2( i,: )=bestX+randn(1,dim).*((abs(( pX(i,:  )-bestXX)))+(abs(( pX(i,:  )-bestX))))./2;
        if G_ms(P(i,1),P(i,2))>65 && 9.99 / (P(i,1)*P(i,2)) <1%要分情况讨论，还有就是在边界的时候
            
            P(i, : ) =  P2(i, : ) ;
            if  P(i, 1 ) <MinX(1)
                P(i, 1) =MinX(1);
            end
            if  P(i, 2 ) <MinX(2)
                P(i, 2) =MinX(2);
            end
            if  P(i, 2 ) >MaxX(2)
                P(i, 2) =MaxX(2);
            end
            fit(i)=dgm(P2(i,1),P2(i,2));
        else
            continue
        end
        %       fit( j ) = fobj( P( j, : ),Function_name );
    end
    XX=pX;
    for i = 1 : (gd-1)
        if ( fit( i ) >pFit( i ) )
            pFit( i ) = fit( i );
            pX( i, : ) = P( i, : );
        end
        
        if( pFit( i ) >fMax )
            fMax= pFit( i );
            bestX = pX( i, : );      
        end
    end

    
    ymat(t,1)=fMax;
    disp(['In iteration ' num2str(t) ' : the optimal vakue is ' num2str(fMax)]);
end

plot(ymat);

