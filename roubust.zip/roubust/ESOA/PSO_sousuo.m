clc;clear;close all;
%% 初始化种群
lambda=9.99;
N = 50;                         % 初始种群个数
d = 2;                          % 空间维数
ger = 20;                      % 最大迭代次数     
limit = [6 20;0.5 2];                % 设置位置参数限制
vlimit = [-2,2;-0.2,0.2]; 
w = 0.8;                        % 惯性权重
c1 = 0.5;                       % 自我学习因子
c2 = 0.5;                       % 群体学习因子 
for i = 1:d
    x(:,i) = limit(i, 1) + (limit(i, 2) - limit(i, 1)) * rand(N, 1);%初始种群的位置
end
v = rand(N, d);                  % 初始种群的速度
xm = zeros(N, d);                % 每个个体的历史最佳位置
ym = zeros(1, d);                % 种群的历史最佳位置
fxm = zeros(N, 1);               % 每个个体的历史最佳适应度
fxm(:,1)=inf;
fym = inf;                       % 种群历史最佳适应度
fx=zeros(N,1);
%% 群体更新
iter = 1;
record = zeros(ger, 1);          % 记录器
while iter <= ger
    
    for k=1:N
        if lambda/(x(k,1)*x(k,2))<1 && T_ms(x(k,1),x(k,2))<0.001
%             fx(k) =max(-dgm(x(k,1),x(k,2)),-dtm(x(k,1),x(k,2)));
            fx(k) =-dtm(x(k,1),x(k,2));
        else
            fx(k)=0;
        end
    end
    for i = 1:N
        if (fxm(i,:) > fx(i,:))
            fxm(i,:) = fx(i,:);     % 更新个体历史最佳适应度(即：看谁的f_min更小，并把每个粒子历史上最小的f_min存起来）
            xm(i,:) = x(i,:);   % 更新个体历史最佳位置
        end
    end
    if fym > min(fxm)
        [fym, nmin] = min(fxm);   % 更新群体历史最佳适应度 找最小值
        ym = xm(nmin, :);      % 更新群体历史最佳位置
    end
    for i=1:d
        for i=1:d
            v(:,i) = v(:,i) * w + c1 * rand *(xm(:,i) - x(:,i)) + c2 * rand *(repmat(ym(i),N,1) - x(:,i));%速度更新
        end
    end
    % 边界速度处理
    for i=1:d
        for j=1:N
            if  v(j,i)>vlimit(i,2)
                v(j,i)=vlimit(i,2);
            end
            if  v(j,i) < vlimit(i,1)
                v(j,i)=vlimit(i,1);
            end
        end
    end
    x = x + v;            % 位置更新
    for i=1:d            % 边界位置处理
        for j=1:N
            if  x(j,i)>limit(i,2)
                x(j,i)=limit(i,2);
            end
            if  x(j,i) < limit(i,1)
                x(j,i)=limit(i,1);
            end
        end
    end
    record(iter) = fym;
    
    %最大值记录
    %     x0 = 0 : 0.01 : 20;
    %     plot(x0, f(x0), 'b-', x, f(x), 'ro');title('状态位置变化')
    %     pause(0.1)
    iter = iter+1;
    disp(['In iteration ' num2str(iter) ' : the optimal vakue is ' num2str(fym)]);
end
fymm=fym;
ymm=ym(1);
zmm=ym(2);
plot(record)
xlim([0 20])
grid on
hold on
box on
xlabel('iteration')
ylabel('error')