clc;clear;close all;
a=10;delta=0.1;alpha=2.8;P=2;xi=9.4192;D=1;beta=1.5;lambda=9.99;

%% 求 G
f1=@(m,s)lambda.*a.*(1-exp(-m.*s.*(1-(lambda./(m.*s))).*D)./(sqrt(2*pi.*m).*(1-(lambda./(m.*s))).*(exp((lambda./(m.*s)))./(exp(1).*(lambda./(m.*s)))).^m+1))-(m.*beta+delta.*lambda.*xi.*s.^(alpha-1)+delta.*P)-55;
h1=fimplicit(f1,[6 24 0.5 2.5]);
x11=get(h1,'Xdata');
y11=get(h1,'Ydata');
n=length(x11);
for i=1:n
    if lambda/(x11(i)*y11(i))>1 % || y11(i)+1/24*x11(i)-11/6<0
        x11(i)=NaN;
        y11(i)=NaN;
    end
end

f1=@(m,s)lambda.*a.*(1-exp(-m.*s.*(1-(lambda./(m.*s))).*D)./(sqrt(2*pi.*m).*(1-(lambda./(m.*s))).*(exp((lambda./(m.*s)))./(exp(1).*(lambda./(m.*s)))).^m+1))-(m.*beta+delta.*lambda.*xi.*s.^(alpha-1)+delta.*P)-60;
h1=fimplicit(f1,[6 24 0.5 2.5]);
x22=get(h1,'Xdata');
y22=get(h1,'Ydata');
n=length(x22);
for i=1:n
    if lambda/(x22(i)*y22(i))>1 % || y22(i)+1/24*x22(i)-11/6<0
        x22(i)=NaN;
        y22(i)=NaN;
    end
end

f1=@(m,s)lambda.*a.*(1-exp(-m.*s.*(1-(lambda./(m.*s))).*D)./(sqrt(2*pi.*m).*(1-(lambda./(m.*s))).*(exp((lambda./(m.*s)))./(exp(1).*(lambda./(m.*s)))).^m+1))-(m.*beta+delta.*lambda.*xi.*s.^(alpha-1)+delta.*P)-65;
h1=fimplicit(f1,[6 24 0.5 2.5]);
x33=get(h1,'Xdata');
y33=get(h1,'Ydata');
n=length(x33);
for i=1:n
    if lambda/(x33(i)*y33(i))>1 % || y33(i)+1/24*x33(i)-11/6<0
        x33(i)=NaN;
        y33(i)=NaN;
    end
end

%% 求 T
f1 = @(m,s)((exp(m).*((lambda./(m.*s)).^m))./(sqrt(2.*pi.*m).*exp(m.*(lambda./(m.*s))).*((1-(lambda./(m.*s))).^2).*m.*s+(exp(m).*((lambda./(m.*s)).^(m))).*m.*s.*(1-(lambda./(m.*s))).^2)-1);%X为m，y为s
h1=fimplicit(f1,[6 24 0.5 2.5]);
x1=get(h1,'Xdata');
y1=get(h1,'Ydata');
n=length(x1);
for i=1:n
    if lambda/(x1(i)*y1(i))>1
        x1(i)=NaN;
        y1(i)=NaN;
    end
end


f1 = @(m,s)((exp(m).*((lambda./(m.*s)).^m))./(sqrt(2.*pi.*m).*exp(m.*(lambda./(m.*s))).*((1-(lambda./(m.*s))).^2).*m.*s+(exp(m).*((lambda./(m.*s)).^(m))).*m.*s.*(1-(lambda./(m.*s))).^2)-0.1);%X为m，y为s
h1=fimplicit(f1,[6 24 0.5 2.5]);
x2=get(h1,'Xdata');
y2=get(h1,'Ydata');
n=length(x2);
for i=1:n
    if lambda/(x2(i)*y2(i))>1
        x2(i)=NaN;
        y2(i)=NaN;
    end
end


f1 = @(m,s)((exp(m).*((lambda./(m.*s)).^m))./(sqrt(2.*pi.*m).*exp(m.*(lambda./(m.*s))).*((1-(lambda./(m.*s))).^2).*m.*s+(exp(m).*((lambda./(m.*s)).^(m))).*m.*s.*(1-(lambda./(m.*s))).^2)-0.001);%X为m，y为s
h1=fimplicit(f1,[6 24 0.5 2.5]);
x3=get(h1,'Xdata');
y3=get(h1,'Ydata');
n=length(x3);
for i=1:n
    if lambda/(x3(i)*y3(i))>1 
        x3(i)=NaN;
        y3(i)=NaN;
    end
end

%% 求rho

lambda=9.99;
 f4=@(m,s)(lambda/(m*s)-1);
 h1=fimplicit(f4,[6 20 0.5 2.5]);
x4=get(h1,'Xdata');
y4=get(h1,'Ydata');


figure(3) %T & G
hold on 
plot(x33,y33,x3,y3,x4,y4,'--k')
% r = 0.205;%半径
% a = 13.1819;%横坐标
% b = 1.0878;%纵坐标   
% para = [a-r, b-r, 2*r, 2*r];
% r = 1.075;%半径
% a = 20;%横坐标
% b = 2;%纵坐标   
% para = [a-r, b-r, 2*r, 2*r];
% plot(a,b,'.','Color','r','MarkerSize',20)
% rectangle('Position', para, 'Curvature', [1 1]);
r = 0.205;%半径
a = 12.7610;%横坐标
b = 1.1186;%纵坐标   
para = [a-r, b-r, 2*r, 2*r];
plot(a,b,'.','Color','r','MarkerSize',20)
rectangle('Position', para, 'Curvature', [1 1]);
legend('G=65','T=0.001','\rho=1')
ylim([0.5 2])
xlim([6 24])
ylabel('server speed')
xlabel('server size')
hold on
grid on
box on
